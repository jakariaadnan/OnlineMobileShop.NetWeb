﻿using System.Web.UI;

namespace _7thExamProject.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}